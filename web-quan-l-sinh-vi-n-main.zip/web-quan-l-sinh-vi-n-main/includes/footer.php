    <footer class="bg-dark text-light text-center mt-auto">
        <div class="position-relative">
            <a href="../public/logout.php" class="btn btn-danger float-end">
                <i><i class="bi bi-box-arrow-right"></i></i>
            </a>
            <h5>Copyright@PhpWebApp.com</h5>
        </div>
    </footer>