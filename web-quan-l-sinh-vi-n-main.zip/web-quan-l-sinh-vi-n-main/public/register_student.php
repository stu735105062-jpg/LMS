<?php
session_start();
// 1. Kết nối Database
$conn = mysqli_connect('localhost', 'root', '', 'student_management');
mysqli_set_charset($conn, "utf8mb4");

// 2. CHỈ ADMIN MỚI ĐƯỢC VÀO TRANG NÀY
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: home.php");
    exit();
}

$msg = ""; $error = "";

// 3. XỬ LÝ KHI NHẤN NÚT ĐĂNG KÝ
if (isset($_POST['btn_register'])) {
    $name     = mysqli_real_escape_string($conn, $_POST['name']);
    $email    = mysqli_real_escape_string($conn, $_POST['email']);
    $phone    = mysqli_real_escape_string($conn, $_POST['phone']);
    $address  = mysqli_real_escape_string($conn, $_POST['address']);
    
    // Mật khẩu mặc định
    $password = "123456"; 

    // Kiểm tra email tồn tại chưa
    $check = mysqli_query($conn, "SELECT id FROM users WHERE username = '$email'");
    if (mysqli_num_rows($check) > 0) {
        $error = "Email này đã được đăng ký tài khoản!";
    } else {
        mysqli_begin_transaction($conn);
        try {
            // A. Tạo tài khoản đăng nhập
            mysqli_query($conn, "INSERT INTO users (username, password, role) VALUES ('$email', '$password', 'student')");
            $user_id = mysqli_insert_id($conn);

            // B. Tạo thông tin hồ sơ
            $sql_info = "INSERT INTO student_info (user_id, name, email, phone, address) 
                         VALUES ($user_id, '$name', '$email', '$phone', '$address')";
            
            if (mysqli_query($conn, $sql_info)) {
                mysqli_commit($conn);
                // Thông báo mật khẩu mặc định ở đây
                $msg = "Tạo tài khoản thành công! <br> Mật khẩu đăng nhập mặc định là: <b>$password</b>";
            } else {
                throw new Exception(mysqli_error($conn));
            }
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "Lỗi hệ thống: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Đăng ký sinh viên mới - Admin Only</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        .alert-success b { font-size: 1.1rem; color: #0f5132; text-decoration: underline; }
    </style>
</head>
<body class="bg-light">

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <a href="home.php" class="btn btn-link mb-3 text-decoration-none"><i class="bi bi-arrow-left"></i> Quay lại Dashboard</a>
            
            <div class="card shadow border-0 rounded-4">
                <div class="card-body p-4">
                    <h3 class="fw-bold text-center mb-4 text-primary">ĐĂNG KÝ SINH VIÊN MỚI</h3>
                    <p class="text-center text-muted small">Tài khoản được tạo sẽ có quyền truy cập hệ thống dành cho Student</p>

                    <?php if($msg): ?> 
                        <div class="alert alert-success alert-dismissible fade show shadow-sm">
                            <i class="bi bi-check-circle-fill me-2"></i><?= $msg ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div> 
                    <?php endif; ?>

                    <?php if($error): ?> 
                        <div class="alert alert-danger alert-dismissible fade show shadow-sm">
                            <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div> 
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label fw-bold small">HỌ VÀ TÊN</label>
                            <input type="text" name="name" class="form-control" placeholder="Nguyễn Văn A" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small">EMAIL (Tên đăng nhập)</label>
                            <input type="email" name="email" class="form-control" placeholder="email@gmail.com" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label fw-bold small">SỐ ĐIỆN THOẠI</label>
                            <input type="text" name="phone" class="form-control" placeholder="09xxx">
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold small">ĐỊA CHỈ THƯỜNG TRÚ</label>
                            <textarea name="address" class="form-control" rows="2" placeholder="Số nhà, đường, quận, thành phố..."></textarea>
                        </div>

                        <button type="submit" name="btn_register" class="btn btn-primary w-100 py-2 fw-bold shadow-sm">
                            <i class="bi bi-person-plus-fill me-2"></i> XÁC NHẬN TẠO TÀI KHOẢN
                        </button>
                    </form>
                </div>
            </div>
            
            <div class="text-center mt-3 text-muted small">
                <i class="bi bi-info-circle me-1"></i> Sinh viên nên đổi mật khẩu sau lần đăng nhập đầu tiên.
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>