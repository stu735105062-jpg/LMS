-- ============================================================
-- SQL SCRIPT: KHỞI TẠO HỆ THỐNG QUẢN LÝ SINH VIÊN
-- ============================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

-- 1. XÓA DATABASE CŨ VÀ TẠO MỚI (Để làm sạch dữ liệu từ đầu)
DROP DATABASE IF EXISTS `student_management`;
CREATE DATABASE `student_management` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `student_management`;

-- 2. BẢNG USERS (Tài khoản hệ thống)
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL UNIQUE,
  `password` varchar(255) DEFAULT '123456',
  `role` enum('admin', 'teacher', 'student') DEFAULT 'student',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. BẢNG CLASSES (Danh sách lớp học)
CREATE TABLE `classes` (
  `class_id` int NOT NULL AUTO_INCREMENT,
  `class_name` varchar(100) NOT NULL,
  `teacher_name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. BẢNG STUDENT_INFO (Hồ sơ sinh viên)
CREATE TABLE `student_info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `class_id` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL UNIQUE,
  `gender` enum('Nam', 'Nữ', 'Khác') DEFAULT 'Nam',
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_stu_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_stu_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. BẢNG COURSES (Danh sách môn học thuộc các lớp)
CREATE TABLE `courses` (
  `course_id` int NOT NULL AUTO_INCREMENT,
  `class_id` int NOT NULL,
  `course_name` varchar(255) NOT NULL,
  PRIMARY KEY (`course_id`),
  CONSTRAINT `fk_course_class` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. BẢNG COURSE_REGISTRATIONS (Cầu nối để đồng bộ môn học giữa quản lý và sinh viên)
CREATE TABLE `course_registrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `course_id` int NOT NULL,
  `registered_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_registration` (`student_id`, `course_id`),
  CONSTRAINT `fk_reg_student` FOREIGN KEY (`student_id`) REFERENCES `student_info` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reg_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. BẢNG GRADES (Điểm số môn học)
CREATE TABLE `grades` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `course_id` int NOT NULL,
  `score` decimal(4,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_grade` (`student_id`, `course_id`),
  CONSTRAINT `fk_grade_student` FOREIGN KEY (`student_id`) REFERENCES `student_info` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_grade_course` FOREIGN KEY (`course_id`) REFERENCES `courses` (`course_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. BẢNG ATTENDANCE (Điểm danh hàng ngày)
CREATE TABLE `attendance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `date` date NOT NULL,
  `status` enum('present', 'absent') DEFAULT 'present',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_attendance` (`student_id`, `date`),
  CONSTRAINT `fk_att_student` FOREIGN KEY (`student_id`) REFERENCES `student_info` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. DỮ LIỆU MẪU MẶC ĐỊNH
-- Tài khoản quản trị: admin@gmail.com / 123456
INSERT INTO `users` (`username`, `password`, `role`) VALUES 
('admin@gmail.com', '123456', 'admin');

-- Ví dụ tạo 1 lớp và 1 môn học mẫu (có thể xóa nếu muốn)
INSERT INTO `classes` (`class_name`, `teacher_name`) VALUES ('Lập trình Web', 'Thầy Nguyễn Văn A');
INSERT INTO `courses` (`class_id`, `course_name`) VALUES (1, 'Lập trình PHP');

COMMIT;