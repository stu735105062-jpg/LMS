<?php
// mail_config.php — put your Gmail / app password here
define('MAIL_HOST', 'smtp.gmail.com');
define('MAIL_PORT', 587);
define('MAIL_USER', 'ahmedsahal@gmail.com');        // <- replace with your Gmail
define('MAIL_PASS', 'Your app pAssword');   // <- replace with App Password from Google
define('MAIL_FROM', 'ahmedsahal@gmail.com');
define('MAIL_FROM_NAME', 'University SMS');
define('MAIL_SECURE', 'tls'); // use 'tls' for port 587
